const options = {
    singleQuote: true,
    tabWidth: 4,
    trailingComma: 'all',
    printWidth: 120,
};

module.exports = options;